#!/bin/bash

python3 ./saves/main.py $@
